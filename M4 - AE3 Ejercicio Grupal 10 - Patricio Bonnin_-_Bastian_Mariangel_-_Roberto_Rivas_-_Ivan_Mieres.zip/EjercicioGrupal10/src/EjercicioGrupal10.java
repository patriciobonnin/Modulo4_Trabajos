import java.util.Scanner;

public class EjercicioGrupal10 {

    /**
     * @author Bastián Mariángel
     * @author Roberto Rivas
     * @author Patricio Bonnin
     * @author Ivan Mieres
     * */

    public static void main(String [] args) {
        Scanner scanner = new Scanner(System.in);

        // Declarar variables

        String dia;
        String hora;
        String lugar;
        String nombre ;
        float calificacion;
        int duracion;
        int cantidadAsistentes;
        float promedio = 0;


        // Solicitar los datos de la capacitacion

        System.out.println("Ingrese los datos de la capacitacion: ");
        System.out.print("Ingrese dia: ");
        dia = scanner.nextLine();
        System.out.print("Ingrese la hora: ");
        hora = scanner.nextLine();
        System.out.print("Ingrese el Lugar: ");
        lugar = scanner.nextLine();
        System.out.print("Duración: ");
        duracion = scanner.nextInt();
        System.out.print("Ingrese cantidad de asistentes : ");
        cantidadAsistentes = scanner.nextInt();


        //Crear la matriz de nombres y calificaciones

        String[][] asistentes = new String[cantidadAsistentes][2];


        System.out.println("Ingrese el nombre del asistente y su calificacion");

        // Llenar la matriz

        for (int i = 0; i < cantidadAsistentes; i++){

            scanner = new Scanner(System.in);
            System.out.println("Ingrese nombre : " );
            nombre = scanner.nextLine();
            System.out.println("Ingrese la calificacion : ");
            calificacion = scanner.nextFloat();
            asistentes[i][0] = nombre;
            asistentes[i][1] = String.valueOf(calificacion);
            promedio += calificacion /cantidadAsistentes;
        }

        // Menor y mayor calificacion
        for (int i = 0; i < cantidadAsistentes-1; i++){
            for (int j = 0; j < cantidadAsistentes-i-1; j++){

                if (Float.parseFloat(asistentes[j][1]) > Float.parseFloat(asistentes[j+1][1])){

                    String temp = asistentes[j][1];
                    asistentes[j][1] = asistentes[j+1][1];
                    asistentes[j+1][1] = temp;

                    String temp2 = asistentes[j][0];
                    asistentes[j][0] = asistentes[j+1][0];
                    asistentes[j+1][0] = temp2;

                }
            }
        }

        // Guardamos los datos en sus respectivas variables.

        float menorCalificacion = Float.parseFloat(asistentes[0][1]) ;
        float mayorCalificacion = Float.parseFloat(asistentes[cantidadAsistentes-1][1]);
        String menorNombre = asistentes[0][0];
        String mayorNombre = asistentes[cantidadAsistentes-1][0];

        // Mostramos todos los datos ya guardados anteriormente.

        System.out.println("Los datos de capacitacion son: ");
        System.out.println("El dia: "+dia + "\nHora: "+ hora+ "\nLugar: "+ lugar + "\nDuracion: "+ duracion+ "\nCantidad de asistentes: "+ cantidadAsistentes);
        System.out.println("El promedio de notas es: " + promedio);
        System.out.println("La calificacion menor es: " + menorCalificacion + " y es de: "+menorNombre);
        System.out.println("La Calificacion mayor es: " + mayorCalificacion + " y es de: "+mayorNombre);


    }
}





