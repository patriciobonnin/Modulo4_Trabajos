public class EjercicioGrupal11 {



    public static void main(String [] args){


        final boolean valorConstante = false;
        String mensaje = "Lorem ipsum dolor sit amet consectetur adipiscing elit. Donec facilisis est ac ante " +
                "viverra, vel efficitur leo consequat. Maecenas quis lorem sit amet diam consequat lacinia non nec lacus. " +
                "Phasellus egestas quam non dui dictum, sed fermentum dolor efficitur. Aliquam volutpat ex sodales pulvinar scelerisque. " +
                "Donec sodales cursus tortor eu aliquam. Curabitur id purus arcu. Vestibulum ante ipsum primis in faucibus orci luctus et " +
                "ultrices posuere cubilia curae; Suspendisse pretium, quam non consectetur scelerisque, diam tortor iaculis arcu, nec tincidunt diam " +
                "eros sed urna. Ut at consequat enim. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec sit amet " +
                "ultricies dui. Donec aliquet rhoncus velit et sollicitudin.";


        int ola;

        ola = 10;
        for (int i = 0; i < ola; i++) {

            System.out.println("Valor: " + (i));
        }

        System.out.println( "El mensaje es: " + mensaje);
        System.out.println(" El valor de la constante es: " + valorConstante);


    }

}

/*
package Clase11;
public class $EjeMpl0_2 {
public static void main(String[] args) {
final boolean valorconstante = false;
String mensaje = "Lorem ipsum dolor sit amet,

consectetur adipiscing elit. Donec facilisis est ac ante viverra,
vel efficitur leo consequat. Maecenas quis lorem sit amet diam
consequat lacinia non nec lacus. Phasellus egestas quam non dui
dictum, sed fermentum dolor efficitur. Aliquam volutpat ex
sodales pulvinar scelerisque. Donec sodales cursus tortor eu
aliquam. Curabitur id purus arcu. Vestibulum ante ipsum primis in
faucibus orci luctus et ultrices posuere cubilia curae;
Suspendisse pretium, quam non consectetur scelerisque, diam
tortor iaculis arcu, nec tincidunt diam eros sed urna. Ut at
consequat enim. Orci varius natoque penatibus et magnis dis
parturient montes, nascetur ridiculus mus. Donec sit amet
ultricies dui. Donec aliquet rhoncus velit et sollicitudin.";
int Ola;
Ola = 10;
for (int i=0;

i<Ola;i++) {

System.out.println("Valor: " + (i*i));
}
//Esto es un comentario
//demasiado grande
//para que esté en una
//sola línea

/*
System.out.println( "El mensaje " + " es" + mensaje); //
System.out.println(" El valor de la constante es: " +
valorconstante);
}
}
 */

   // 1.- El nombre de la clase $EjeMpl0_2 no sigue la convención de nombres de clases en Java, que es CamelCase y no debe comenzar con un carácter especial como $.
   // 2.- La constante valorconstante debe estar en mayúsculas y separada por guiones bajos, como VALOR_CONSTANTE. o tambien con camelcase valorConstante.
   // 3.- La variable Ola debe comenzar con una letra minúscula, como ola.
   // 4.- Las llaves deben estar en la misma línea que la declaración de la estructura de control o método al que pertenecen.
   // 5.- Los comentarios de mas de una linea deben usar /* */
   // 6.- El Mensaje lorem estaba con saltos de linea sin un "+" al final de cada una de ellas, generando errores.
   // 7.- En la línea 61 debe ir el comentario entre comillas: "El mensaje es" + mensaje (variable).
   // 8.- Linea 49 , el for esta incompleto y cortado en otra linea, la expresión lógica debe estar en una sola linea.