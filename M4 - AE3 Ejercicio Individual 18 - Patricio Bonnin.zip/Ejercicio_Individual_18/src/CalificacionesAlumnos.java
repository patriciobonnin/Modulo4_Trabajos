import java.util.Scanner;

public class CalificacionesAlumnos {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        float contadorAlumnos = 0;
        String nombre;
        float calificacion;
        float sumaCalificaciones = 0;
        float menorCalificacion = Integer.MAX_VALUE;
        float mayorCalificacion = Integer.MIN_VALUE;
        String nombreMenorCalificacion = "";
        String nombreMayorCalificacion = "";

        System.out.println("Ingrese el nombre del alumno y su calificación (ingrese 'SALIR' para terminar):");

        while (true) {
            contadorAlumnos++;
            System.out.print("Alumno " + contadorAlumnos + ": ");
            nombre = scanner.nextLine();

            if (nombre.equalsIgnoreCase("SALIR")) {
                if (contadorAlumnos <= 2) {
                    System.out.println("Debe ingresar al menos dos alumnos. El programa ha terminado.");
                    return;
                } else {
                    break;
                }
            }

            System.out.print("Calificación: ");
            calificacion = scanner.nextFloat();
            scanner.nextLine();

            sumaCalificaciones += calificacion;

            if (calificacion < menorCalificacion) {
                menorCalificacion = calificacion;
                nombreMenorCalificacion = nombre;
            }

            if (calificacion > mayorCalificacion) {
                mayorCalificacion = calificacion;
                nombreMayorCalificacion = nombre;
            }
        }

        float promedio = sumaCalificaciones / (contadorAlumnos - 1);

        System.out.println("\n--- Resultados ---");
        System.out.println("Promedio del curso: " + promedio);
        System.out.println("Alumno con la menor calificación: " + nombreMenorCalificacion);
        System.out.println("Alumno con la mayor calificación: " + nombreMayorCalificacion);
    }
}
